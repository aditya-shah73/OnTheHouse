Names:
	Michael Hyun 009828299
	Marta Malapitan 009000264
	Kaanchana Allanki 00981275
	Aditya Shah 008799297

Description:
OntheHouse allows people to post free items that they don’t want on the app so
that other people can view the items and pick it up if they want it. The current prototype
has the following features:
	- Facebook Login Authentication
	- Store User data in Firebase
	- Sign Up (custom)
	- View Free Item Post
	- Import Profile Picture or Free Item Picture
	- Post Free Item
	- View Profile
	- View Homepage (No pictures yet)
To work the app, you can click the Facebook login and put it your user information. The fb login button does not segue, so click the login button to move to the homepage after you have logged in using the Facebook login button. You can also sign up and register, which will also store user data in our firebase database. You can then see our homepage, which is not fully implemented yet. The homepage has a post button, where you can import the picture you want for the free item, and you can write a title and description for the item. Another button on the homepage takes you to the account profile page, which is just a picture for now and will also have other posts associated with that user, but since there are no posts, it is just the profile picture. Screenshots are attached



